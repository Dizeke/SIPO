﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIPO
{
    class ConString
    {
        public static String getConString()
        {
            return "datasource=sql12.freemysqlhosting.net;port=3306;username=sql12194184;password=bkEyN4GMLK;database=sql12194184;";
            //return "server=localhost;user id=root;database=sipo";
        }
    }
}
