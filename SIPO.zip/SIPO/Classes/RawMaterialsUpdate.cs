﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIPO.Classes
{
    class RawMaterialsUpdate
    {
        public static RawMaterials raw;
        public static bool hasSelected;

    }
}
