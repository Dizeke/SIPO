﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIPO.Classes
{
    class AccountUpdateHolder
    {
        public static Account account;
        public static bool hasSelected;
    }
}
